﻿namespace MinecraftClient.Protocol.SessionCache
{
    public enum CacheType { None, Memory, Disk };
}
